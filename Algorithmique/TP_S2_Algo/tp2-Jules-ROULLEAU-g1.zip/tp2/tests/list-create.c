#include <stdio.h>
#include <stdlib.h>
#include "hashtable.h"

int main(int argc, char ** argv) {
	list * l = listCreate();
	if (l==NULL) {
		return 0;
	}
	else {
		return 1;
	}
}
